class UpstashError(Exception):
    pass
